<p align="center">
    <a href="https://app.codacy.com/gh/TEAM-PATRICIA/PatriciaMusic2.0/dashboard?branch=Legacy"> <img src="https://img.shields.io/codacy/grade/4d58f2a402b54aed8a7d95f7add45a81?color=cyan&logo=codacy&logoColor=white&style=for-the-badge" alt="Codacy" /></a>
    <a href="https://github.com/TEAM-PATRICIA/PatriciaMusic2.0"> <img src="https://img.shields.io/github/repo-size/TeamInnexia/innexiaBot?color=cyan&logo=github&logoColor=white&style=for-the-badge" /></a>
</p>


# Pᴀᴛʀɪᴄɪᴀ•Mᴜsɪᴄ👮
💡 This is Innexia An Advanced Telegram CHAT Bot For Best AI Experience !! 🤖 

![logo](https://telegra.ph/file/4d1c1151214987122659b.jpg)
#  💡Dᴇᴠᴇʟᴏᴩᴇᴍᴇɴᴛ•Sᴜᴩᴩᴏʀᴛ👥[Here !](https://t.me/patricia_support)

## Me On Telegram As [💥 Pᴀᴛʀɪᴄɪᴀ 💥](https://t.me/PATRICIA_ROBOT)

## Cᴏᴍᴍᴀɴᴅs
```
->Music•Player<-
=>> *Song Playing* 🎧 
❍ /play  - play song you requested
❍ /dplay  - play song you requested via deezer
❍ /splay  - play song you requested via jio saavn
❍ /playlist - Show now playing list
❍ /current - Show now playing
❍ /song  - download songs you want quickly
❍ /search  - search videos on youtube with details
❍ /deezer  - download songs you want quickly via deezer
❍ /saavn  - download songs you want quickly via saavn
❍ /video  - download videos you want quickly
=>> *Admins only*
❍ /player - open music player settings panel
❍ /pause - pause song play
❍ /resume - resume song play
❍ /skip - play next song
❍ /end - stop music play
❍ /userbotjoin - invite assistant to your chat
❍ /admincache - Refresh admin list

```


## 💡 How To Host ❓️
The easiest way to deploy this Bot
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/TEAM-PATRICIA/PatriciaMusic2.0"><img align="center" alt="Heroku" width="52px" src="https://www.nicepng.com/png/full/223-2233246_heroku-logo-salesforce-heroku.png"></p>
 

